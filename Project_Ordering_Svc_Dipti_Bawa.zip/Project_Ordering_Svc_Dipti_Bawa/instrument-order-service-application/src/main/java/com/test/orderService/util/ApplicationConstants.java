package com.test.orderService.util;

public class ApplicationConstants {

	public static final String LIMIT_ORDER = "L";
	public static final String MARKET_ORDER = "M";

}
