package com.test.orderService.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.test.orderService.entity.Instrument;

@Component("InstrumentDAOImpl")
@Repository
public class InstrumentDAOImpl implements InstrumentDAO {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<Instrument> getAllInstruments() {
		return mongoTemplate.findAll(Instrument.class);
	}

	@Override
	public Instrument getInstrumentById(Integer id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		return mongoTemplate.findOne(query, Instrument.class);
	}

	@Override
	public Instrument addInstrument(Instrument instrument) {
		mongoTemplate.save(instrument);
		// Now, user object will contain the ID as well
		return instrument;
	}

}
