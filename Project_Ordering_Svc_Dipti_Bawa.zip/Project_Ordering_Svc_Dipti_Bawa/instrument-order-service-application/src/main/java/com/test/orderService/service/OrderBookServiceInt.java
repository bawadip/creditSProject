package com.test.orderService.service;

import java.util.List;

import com.test.orderService.entity.Execution;
import com.test.orderService.entity.Instrument;
import com.test.orderService.entity.LimitBreakDown;
import com.test.orderService.entity.Order;
import com.test.orderService.entity.OrderBook;
import com.test.orderService.entity.OrderBookStatistics;

public interface OrderBookServiceInt {

	public OrderBook addOrderBook(Instrument inst);

	public OrderBook closeOrderBook(String bookId);

	public String executeBook(Execution exec);

	public boolean isBookExists(String instID);

	public boolean isValidInstrument(String id);

	public List<OrderBook> findBookByInstID(String instID);

	public OrderBook getBook(String id);

	public OrderBookStatistics getOrderBookStatistics(String bookId);

	public List<Order> getAllOrdersForBook(String bookId);

	public List<LimitBreakDown> getOrderBookLimitBreakdown(String bookId);

	public List<OrderBook> fetchOrderBooks();
}
