package com.test.orderService.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document
public class Order {

	// @Indexed(name="orderId", unique=true)
	@Id
	private String orderID;
	private String orderBookID;
	private String priceType;
	private Integer quantity;
	private Boolean isValid;
	private Double price;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date entryDate;
	private Double executedPrice;
	private Integer executedQuantity;
	private Boolean isExecutionCompleted;

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getPriceType() {
		return priceType;
	}

	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getOrderBookID() {
		return orderBookID;
	}

	public void setOrderBookID(String orderBookID) {
		this.orderBookID = orderBookID;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public Integer getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Integer executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getExecutedPrice() {
		return executedPrice;
	}

	public void setExecutedPrice(Double executedPrice) {
		this.executedPrice = executedPrice;
	}

	public Boolean getIsExecutionCompleted() {
		return isExecutionCompleted;
	}

	public void setIsExecutionCompleted(Boolean isExecutionCompleted) {
		this.isExecutionCompleted = isExecutionCompleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderID == null) ? 0 : orderID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {/*
										 * if (this == obj) return true; if (obj == null) return false; if (getClass()
										 * != obj.getClass()) return false; Order other = (Order) obj; if (orderID ==
										 * null) { if (other.orderID != null) return false; } else if
										 * (!orderID.equals(other.orderID)) return false; return true;
										 */
		Order order = (Order) obj;
		boolean status = false;

		if (this.getIsExecutionCompleted().booleanValue() == order.getIsExecutionCompleted().booleanValue()
				&& this.getIsValid().booleanValue() == order.getIsValid().booleanValue()
				&& this.getEntryDate().equals(order.getEntryDate())
				&& this.getExecutedPrice().doubleValue() == order.getExecutedPrice().doubleValue()
				&& this.getExecutedQuantity().doubleValue() == order.getExecutedQuantity().doubleValue()
				&& this.getOrderBookID().equals(order.getOrderBookID()) && this.getOrderID().equals(order.getOrderID())
				&& this.getPrice().doubleValue() == order.getPrice().doubleValue()
				&& this.getPriceType().equals(order.getPriceType())
				&& this.getQuantity().doubleValue() == order.getQuantity().doubleValue())
			status = true;
		return status;

	}

}
