package com.test.orderService.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document
public class OrderBookStatistics {

	@Id
	private String ID;
	private String orderBookID;
	private Integer demand;
	private Integer numberofOrders;
	private Integer biggestOrder;
	private Integer smallestOrder;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date earliestentryDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date lastentryDate;
	private Integer accumulatedExecQty;
	private Integer numberOfValidOrders;
	private Integer numberOfInValidOrders;

	private Double executionPrice;

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getOrderBookID() {
		return orderBookID;
	}

	public void setOrderBookID(String orderBookID) {
		this.orderBookID = orderBookID;
	}

	public Integer getDemand() {
		return demand;
	}

	public void setDemand(Integer demand) {
		this.demand = demand;
	}

	public Integer getNumberofOrders() {
		return numberofOrders;
	}

	public void setNumberofOrders(Integer numberofOrders) {
		this.numberofOrders = numberofOrders;
	}

	public Integer getBiggestOrder() {
		return biggestOrder;
	}

	public void setBiggestOrder(Integer biggestOrder) {
		this.biggestOrder = biggestOrder;
	}

	public Integer getSmallestOrder() {
		return smallestOrder;
	}

	public void setSmallestOrder(Integer smallestOrder) {
		this.smallestOrder = smallestOrder;
	}

	public Date getEarliestentryDate() {
		return earliestentryDate;
	}

	public void setEarliestentryDate(Date earliestentryDate) {
		this.earliestentryDate = earliestentryDate;
	}

	public Date getLastentryDate() {
		return lastentryDate;
	}

	public void setLastentryDate(Date lastentryDate) {
		this.lastentryDate = lastentryDate;
	}

	public Integer getAccumulatedExecQty() {
		return accumulatedExecQty;
	}

	public void setAccumulatedExecQty(Integer accumulatedExecQty) {
		this.accumulatedExecQty = accumulatedExecQty;
	}

	public Integer getNumberOfValidOrders() {
		return numberOfValidOrders;
	}

	public void setNumberOfValidOrders(Integer numberOfValidOrders) {
		this.numberOfValidOrders = numberOfValidOrders;
	}

	public Integer getNumberOfInValidOrders() {
		return numberOfInValidOrders;
	}

	public void setNumberOfInValidOrders(Integer numberOfInValidOrders) {
		this.numberOfInValidOrders = numberOfInValidOrders;
	}

	public Double getExecutionPrice() {
		return executionPrice;
	}

	public void setExecutionPrice(Double executionPrice) {
		this.executionPrice = executionPrice;
	}

}
