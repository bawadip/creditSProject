package com.test.orderService.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.test.orderService.entity.OrderBook;

@Repository
public interface OrderBookRepository extends MongoRepository<OrderBook, String> {

	@Query("{ 'instrumentID': ?0}")
	List<OrderBook> findByInstID(String instrumentID);

}
