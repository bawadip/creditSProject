package test.order;

import static org.junit.Assert.assertArrayEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.test.orderService.dao.OrderBookDAO;
import com.test.orderService.entity.Execution;
import com.test.orderService.entity.Order;
import com.test.orderService.service.OrderBookService;
import com.test.orderService.util.ApplicationConstants;

public class ExecuteOrderTest {

	@Mock
	private OrderBookDAO mockedOrderBookDao;

	@InjectMocks
	private OrderBookService orderBookService;

	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);

		Mockito.doNothing().when(mockedOrderBookDao).updateExecutionCompleted(Mockito.anyObject());
	}

	@Test
	public void testExecuteBook() throws Exception {

		Order inputOrder = new Order();
		Order inputOrder1 = new Order();
		Order expectedOrder = new Order();
		Order expectedOrder1 = new Order();
		Execution exec = new Execution();
		// OrderBookService ob = new OrderBookService();

		inputOrder.setOrderID(UUID.randomUUID().toString());
		Date date = new Date();
		inputOrder.setEntryDate(date);
		inputOrder.setIsValid(true);
		inputOrder.setOrderBookID(UUID.randomUUID().toString());
		inputOrder.setPrice(200.00);
		inputOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder.setQuantity(100);
		inputOrder.setExecutedQuantity(0);
		inputOrder.setIsExecutionCompleted(false);

		inputOrder1.setOrderID(UUID.randomUUID().toString());
		inputOrder1.setEntryDate(date);
		inputOrder1.setIsValid(true);
		inputOrder1.setOrderBookID(inputOrder.getOrderBookID());
		inputOrder1.setPrice(null);
		inputOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		inputOrder1.setQuantity(100);
		inputOrder1.setExecutedQuantity(0);
		inputOrder1.setIsExecutionCompleted(false);

		expectedOrder.setOrderID(inputOrder.getOrderID());
		expectedOrder.setEntryDate(inputOrder.getEntryDate());
		expectedOrder.setIsValid(true);
		expectedOrder.setOrderBookID(inputOrder.getOrderBookID());
		expectedOrder.setPrice(200.00);
		expectedOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		expectedOrder.setQuantity(100);
		expectedOrder.setIsExecutionCompleted(true);
		expectedOrder.setExecutedPrice(200.00);
		expectedOrder.setExecutedQuantity(100);

		expectedOrder1.setOrderID(inputOrder1.getOrderID());
		expectedOrder1.setEntryDate(inputOrder1.getEntryDate());
		expectedOrder1.setIsValid(true);
		expectedOrder1.setOrderBookID(inputOrder1.getOrderBookID());
		expectedOrder1.setPrice(null);
		expectedOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		expectedOrder1.setQuantity(100);
		expectedOrder1.setIsExecutionCompleted(true);
		expectedOrder1.setExecutedPrice(200.00);
		expectedOrder1.setExecutedQuantity(100);

		exec.setBookID(inputOrder.getOrderBookID()); //
		exec.setExecDate(date);
		exec.setExecPrice(200.00);
		exec.setExecQuantity(200);

		List<Order> inputOrderList = new ArrayList<>();
		List<Order> expectedOrderList = new ArrayList<>();
		inputOrderList.add(inputOrder);
		inputOrderList.add(inputOrder1);
		expectedOrderList.add(expectedOrder);
		expectedOrderList.add(expectedOrder1);

		List<Order> resultOrderList = orderBookService.executeOrder(inputOrderList, exec);
		assertArrayEquals(expectedOrderList.toArray(), resultOrderList.toArray());
	}

	@Test
	public void testExecuteBookWith_ExecutionQuantity_LessThanValidAccumaltedDemandQuantity() throws Exception {

		Order inputOrder = new Order();
		Order inputOrder1 = new Order();
		Order inputOrder2 = new Order();
		Order expectedOrder = new Order();
		Order expectedOrder1 = new Order();
		Order expectedOrder2 = new Order();
		Execution exec = new Execution();
		// OrderBookService ob = new OrderBookService();

		inputOrder.setOrderID(UUID.randomUUID().toString());
		Date date = new Date();
		inputOrder.setEntryDate(date);
		inputOrder.setIsValid(true);
		inputOrder.setOrderBookID(UUID.randomUUID().toString());
		inputOrder.setPrice(200.00);
		inputOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder.setQuantity(100);
		inputOrder.setExecutedQuantity(0);
		inputOrder.setIsExecutionCompleted(false);

		inputOrder1.setOrderID(UUID.randomUUID().toString());
		inputOrder1.setEntryDate(date);
		inputOrder1.setIsValid(true);
		inputOrder1.setOrderBookID(inputOrder.getOrderBookID());
		inputOrder1.setPrice(null);
		inputOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		inputOrder1.setQuantity(100);
		inputOrder1.setExecutedQuantity(0);
		inputOrder1.setIsExecutionCompleted(false);

		inputOrder2.setOrderID(UUID.randomUUID().toString());
		inputOrder2.setEntryDate(date);
		inputOrder2.setIsValid(true);
		inputOrder2.setOrderBookID(inputOrder.getOrderBookID());
		inputOrder2.setPrice(220.00);
		inputOrder2.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder2.setQuantity(100);
		inputOrder2.setExecutedQuantity(0);
		inputOrder2.setIsExecutionCompleted(false);

		expectedOrder.setOrderID(inputOrder.getOrderID());
		expectedOrder.setEntryDate(inputOrder.getEntryDate());
		expectedOrder.setIsValid(true);
		expectedOrder.setOrderBookID(inputOrder.getOrderBookID());
		expectedOrder.setPrice(200.00);
		expectedOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		expectedOrder.setQuantity(100);
		expectedOrder.setIsExecutionCompleted(false);
		expectedOrder.setExecutedPrice(200.00);
		expectedOrder.setExecutedQuantity(67);

		expectedOrder1.setOrderID(inputOrder1.getOrderID());
		expectedOrder1.setEntryDate(inputOrder1.getEntryDate());
		expectedOrder1.setIsValid(true);
		expectedOrder1.setOrderBookID(inputOrder1.getOrderBookID());
		expectedOrder1.setPrice(null);
		expectedOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		expectedOrder1.setQuantity(100);
		expectedOrder1.setIsExecutionCompleted(false);
		expectedOrder1.setExecutedPrice(200.00);
		expectedOrder1.setExecutedQuantity(67);

		expectedOrder2.setOrderID(inputOrder2.getOrderID());
		expectedOrder2.setEntryDate(inputOrder2.getEntryDate());
		expectedOrder2.setIsValid(true);
		expectedOrder2.setOrderBookID(inputOrder.getOrderBookID());
		expectedOrder2.setPrice(220.00);
		expectedOrder2.setPriceType(ApplicationConstants.LIMIT_ORDER);
		expectedOrder2.setQuantity(100);
		expectedOrder2.setIsExecutionCompleted(false);
		expectedOrder2.setExecutedPrice(200.00);
		expectedOrder2.setExecutedQuantity(66);

		exec.setBookID(inputOrder.getOrderBookID()); //
		exec.setExecDate(date);
		exec.setExecPrice(200.00);
		exec.setExecQuantity(200);

		List<Order> inputOrderList = new ArrayList<>();
		List<Order> expectedOrderList = new ArrayList<>();
		inputOrderList.add(inputOrder);
		inputOrderList.add(inputOrder1);
		inputOrderList.add(inputOrder2);
		expectedOrderList.add(expectedOrder);
		expectedOrderList.add(expectedOrder1);
		expectedOrderList.add(expectedOrder2);
		List<Order> resultOrderList = orderBookService.executeOrder(inputOrderList, exec);
		assertArrayEquals(expectedOrderList.toArray(), resultOrderList.toArray());
	}

	@Test
	public void testExecuteBookWith_MultipleExecutions() throws Exception {

		Order inputOrder = new Order();
		Order inputOrder1 = new Order();
		Order inputOrder2 = new Order();
		Order expectedOrder = new Order();
		Order expectedOrder1 = new Order();
		Order expectedOrder2 = new Order();
		Execution exec = new Execution();
		Execution exec1 = new Execution();

		// OrderBookService ob = new OrderBookService();

		inputOrder.setOrderID(UUID.randomUUID().toString());
		Date date = new Date();
		inputOrder.setEntryDate(date);
		inputOrder.setIsValid(true);
		inputOrder.setOrderBookID(UUID.randomUUID().toString());
		inputOrder.setPrice(200.00);
		inputOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder.setQuantity(100);
		inputOrder.setExecutedQuantity(0);
		inputOrder.setIsExecutionCompleted(false);

		inputOrder1.setOrderID(UUID.randomUUID().toString());
		inputOrder1.setEntryDate(date);
		inputOrder1.setIsValid(true);
		inputOrder1.setOrderBookID(inputOrder.getOrderBookID());
		inputOrder1.setPrice(null);
		inputOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		inputOrder1.setQuantity(100);
		inputOrder1.setExecutedQuantity(0);
		inputOrder1.setIsExecutionCompleted(false);

		inputOrder2.setOrderID(UUID.randomUUID().toString());
		inputOrder2.setEntryDate(date);
		inputOrder2.setIsValid(true);
		inputOrder2.setOrderBookID(inputOrder.getOrderBookID());
		inputOrder2.setPrice(220.00);
		inputOrder2.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder2.setQuantity(100);
		inputOrder2.setExecutedQuantity(0);
		inputOrder2.setIsExecutionCompleted(false);

		expectedOrder.setOrderID(inputOrder.getOrderID());
		expectedOrder.setEntryDate(inputOrder.getEntryDate());
		expectedOrder.setIsValid(true);
		expectedOrder.setOrderBookID(inputOrder.getOrderBookID());
		expectedOrder.setPrice(200.00);
		expectedOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		expectedOrder.setQuantity(100);
		expectedOrder.setIsExecutionCompleted(true);
		expectedOrder.setExecutedPrice(200.00);
		expectedOrder.setExecutedQuantity(100);

		expectedOrder1.setOrderID(inputOrder1.getOrderID());
		expectedOrder1.setEntryDate(inputOrder1.getEntryDate());
		expectedOrder1.setIsValid(true);
		expectedOrder1.setOrderBookID(inputOrder1.getOrderBookID());
		expectedOrder1.setPrice(null);
		expectedOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		expectedOrder1.setQuantity(100);
		expectedOrder1.setIsExecutionCompleted(true);
		expectedOrder1.setExecutedPrice(200.00);
		expectedOrder1.setExecutedQuantity(100);

		expectedOrder2.setOrderID(inputOrder2.getOrderID());
		expectedOrder2.setEntryDate(inputOrder2.getEntryDate());
		expectedOrder2.setIsValid(true);
		expectedOrder2.setOrderBookID(inputOrder.getOrderBookID());
		expectedOrder2.setPrice(220.00);
		expectedOrder2.setPriceType(ApplicationConstants.LIMIT_ORDER);
		expectedOrder2.setQuantity(100);
		expectedOrder2.setIsExecutionCompleted(true);
		expectedOrder2.setExecutedPrice(200.00);
		expectedOrder2.setExecutedQuantity(100);

		exec.setBookID(inputOrder.getOrderBookID()); //
		exec.setExecDate(date);
		exec.setExecPrice(200.00);
		exec.setExecQuantity(200);

		exec1.setBookID(inputOrder.getOrderBookID()); //
		exec1.setExecDate(date);
		exec1.setExecPrice(200.00);
		exec1.setExecQuantity(100);

		List<Order> inputOrderList = new ArrayList<>();
		List<Order> expectedOrderList = new ArrayList<>();
		inputOrderList.add(inputOrder);
		inputOrderList.add(inputOrder1);
		inputOrderList.add(inputOrder2);
		expectedOrderList.add(expectedOrder);
		expectedOrderList.add(expectedOrder1);
		expectedOrderList.add(expectedOrder2);
		List<Order> resultOrderList = orderBookService.executeOrder(inputOrderList, exec);
		List<Order> resultOrderList1 = orderBookService.executeOrder(resultOrderList, exec1);

		assertArrayEquals(expectedOrderList.toArray(), resultOrderList1.toArray());
	}
}
