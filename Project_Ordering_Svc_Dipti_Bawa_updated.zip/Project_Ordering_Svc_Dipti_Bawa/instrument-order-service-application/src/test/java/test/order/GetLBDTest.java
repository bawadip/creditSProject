package test.order;

import static org.junit.Assert.assertArrayEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.test.orderService.dao.OrderRepository;
import com.test.orderService.entity.LimitBreakDown;
import com.test.orderService.entity.Order;
import com.test.orderService.service.OrderBookService;
import com.test.orderService.util.ApplicationConstants;

public class GetLBDTest {

	@Mock
	private OrderRepository mockedOrderRepository;

	@InjectMocks
	private OrderBookService orderBookService;

	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		Order inputOrder = new Order();
		Order inputOrder1 = new Order();
		Order inputOrder2 = new Order();
		Order inputOrder3 = new Order();
		Date date = new Date();
		inputOrder.setOrderID(UUID.randomUUID().toString());

		inputOrder.setEntryDate(date);
		inputOrder.setIsValid(true);
		inputOrder.setOrderBookID("1234");
		inputOrder.setPrice(200.00);
		inputOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder.setQuantity(150);
		inputOrder.setExecutedQuantity(150);
		inputOrder.setIsExecutionCompleted(true);
		inputOrder.setExecutedPrice(200.00);

		inputOrder1.setOrderID(UUID.randomUUID().toString());
		inputOrder1.setEntryDate(date);
		inputOrder1.setIsValid(true);
		inputOrder1.setOrderBookID("1234");
		inputOrder1.setPrice(null);
		inputOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		inputOrder1.setQuantity(50);
		inputOrder1.setExecutedQuantity(50);
		inputOrder1.setIsExecutionCompleted(true);
		inputOrder.setExecutedPrice(200.00);

		inputOrder2.setOrderID(UUID.randomUUID().toString());
		inputOrder2.setEntryDate(date);
		inputOrder2.setIsValid(true);
		inputOrder2.setOrderBookID("1234");
		inputOrder2.setPrice(200.00);
		inputOrder2.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder2.setQuantity(150);
		inputOrder2.setExecutedQuantity(150);
		inputOrder2.setIsExecutionCompleted(true);
		inputOrder2.setExecutedPrice(200.00);

		inputOrder3.setOrderID(UUID.randomUUID().toString());
		inputOrder3.setEntryDate(date);
		inputOrder3.setIsValid(true);
		inputOrder3.setOrderBookID("1234");
		inputOrder3.setPrice(210.00);
		inputOrder3.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder3.setQuantity(150);
		inputOrder3.setExecutedQuantity(150);
		inputOrder3.setIsExecutionCompleted(true);
		inputOrder3.setExecutedPrice(200.00);

		List<Order> inputOrderList = new ArrayList<>();
		inputOrderList.add(inputOrder);
		inputOrderList.add(inputOrder1);
		inputOrderList.add(inputOrder2);
		inputOrderList.add(inputOrder3);

		Mockito.when(mockedOrderRepository.findBybookID(Mockito.anyString())).thenReturn(inputOrderList);

	}

	@Test
	public void testgetLBD() throws Exception {
		LimitBreakDown lbd1 = new LimitBreakDown();
		LimitBreakDown lbd2 = new LimitBreakDown();

		lbd1.setDemand(450);
		lbd1.setLimitPrice(200.00);
		lbd2.setDemand(150);
		lbd2.setLimitPrice(210.0);
		List<LimitBreakDown> lbd = new ArrayList<>();
		lbd.add(lbd1);
		lbd.add(lbd2);

		List<LimitBreakDown> lbdList = orderBookService.getOrderBookLimitBreakdown("1234");

		assertArrayEquals(lbd.toArray(), lbdList.toArray());
	}

}
