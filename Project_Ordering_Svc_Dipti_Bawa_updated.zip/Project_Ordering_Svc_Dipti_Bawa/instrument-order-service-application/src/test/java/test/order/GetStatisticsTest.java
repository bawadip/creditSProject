package test.order;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.test.orderService.dao.OrderRepository;
import com.test.orderService.entity.Order;
import com.test.orderService.entity.OrderBookStatistics;
import com.test.orderService.service.OrderBookService;
import com.test.orderService.util.ApplicationConstants;

//orderRepository.findBybookID(bookId);
public class GetStatisticsTest {

	@Mock
	private OrderRepository mockedOrderRepository;

	@InjectMocks
	private OrderBookService orderBookService;

	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		Order inputOrder = new Order();
		Order inputOrder1 = new Order();
		inputOrder.setOrderID(UUID.randomUUID().toString());
		try {
			String valuee = "25/04/2018";
			Date currentDate = new SimpleDateFormat("dd/MM/yyyy").parse(valuee);
			inputOrder.setEntryDate(currentDate);
		} catch (Exception e) {
			System.out.println("Error::" + e);
			e.printStackTrace();
		}

		inputOrder.setIsValid(true);
		inputOrder.setOrderBookID("1234");
		inputOrder.setPrice(200.00);
		inputOrder.setPriceType(ApplicationConstants.LIMIT_ORDER);
		inputOrder.setQuantity(150);
		inputOrder.setExecutedQuantity(150);
		inputOrder.setIsExecutionCompleted(true);
		inputOrder.setExecutedPrice(200.00);

		inputOrder1.setOrderID(UUID.randomUUID().toString());
		try {
			String valuee = "01/04/2018";
			Date currentDate = new SimpleDateFormat("dd/MM/yyyy").parse(valuee);
			inputOrder1.setEntryDate(currentDate);
		} catch (Exception e) {
			System.out.println("Error::" + e);
			e.printStackTrace();
		}
		inputOrder1.setIsValid(true);
		inputOrder1.setOrderBookID("1234");
		inputOrder1.setPrice(null);
		inputOrder1.setPriceType(ApplicationConstants.MARKET_ORDER);
		inputOrder1.setQuantity(50);
		inputOrder1.setExecutedQuantity(50);
		inputOrder1.setIsExecutionCompleted(true);
		inputOrder.setExecutedPrice(200.00);

		List<Order> inputOrderList = new ArrayList<>();
		inputOrderList.add(inputOrder);
		inputOrderList.add(inputOrder1);

		Mockito.when(mockedOrderRepository.findBybookID(Mockito.anyString())).thenReturn(inputOrderList);

	}

	@Test
	public void testgetOrderBookStatistics() throws Exception {

		orderBookService.getOrderBookStatistics("1234");
		OrderBookStatistics obs = new OrderBookStatistics();
		obs.setAccumulatedExecQty(200);
		obs.setBiggestOrder(150);
		obs.setSmallestOrder(50);
		obs.setDemand(200);
		obs.setNumberOfValidOrders(2);
		obs.setNumberofOrders(2);
		obs.setNumberOfInValidOrders(0);
		obs.setAccumulatedExecQty(200);
		obs.setExecutionPrice(200.00);
		obs.setOrderBookID("1234");
		try {
			String valuee = "01/04/2018";
			Date currentDateO = new SimpleDateFormat("dd/MM/yyyy").parse(valuee);
			obs.setEarliestentryDate(currentDateO);
		} catch (Exception e) {
			System.out.println("Error::" + e);
			e.printStackTrace();
		}

		try {
			String valuee = "25/04/2018";
			Date currentDateL = new SimpleDateFormat("dd/MM/yyyy").parse(valuee);
			obs.setLastentryDate(currentDateL);
			System.out.println("Date is ::" + currentDateL);
		} catch (Exception e) {
			System.out.println("Error::" + e);
			e.printStackTrace();
		}

		OrderBookStatistics ob = orderBookService.getOrderBookStatistics("1234");

		assertEquals(obs, ob);
	}
}
