package com.test.orderService.dao;

import com.test.orderService.entity.Order;
import com.test.orderService.entity.OrderBook;

public interface OrderBookDAO {

	public OrderBook closeOrderBook(String id);

	public void updateExecutionCompleted(Order order);

}
