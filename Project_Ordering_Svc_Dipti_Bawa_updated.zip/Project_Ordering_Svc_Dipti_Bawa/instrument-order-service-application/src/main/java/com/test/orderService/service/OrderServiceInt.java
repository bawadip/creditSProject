package com.test.orderService.service;

import com.test.orderService.entity.Order;

public interface OrderServiceInt {

	public Order addOrder(Order order);

	public Order getOrder(String orderID);

}
