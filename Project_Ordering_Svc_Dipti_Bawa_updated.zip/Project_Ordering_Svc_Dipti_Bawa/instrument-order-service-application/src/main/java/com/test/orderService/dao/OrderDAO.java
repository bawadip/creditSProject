package com.test.orderService.dao;

import java.util.List;

import com.test.orderService.entity.Order;

public interface OrderDAO {

	Order addOrder(Order order);

	List<Order> findOrderByIDs(List<String> idList);

	void insertInvalidOrder(List<Order> orderList);

	void insertExecutedOrder(List<Order> orderlist);

}
