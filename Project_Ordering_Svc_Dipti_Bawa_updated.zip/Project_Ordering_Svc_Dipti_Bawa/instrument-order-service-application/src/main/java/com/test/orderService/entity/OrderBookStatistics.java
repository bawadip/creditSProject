package com.test.orderService.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document
public class OrderBookStatistics {

	private String orderBookID;
	private Integer demand;
	private Integer numberofOrders;
	private Integer biggestOrder;
	private Integer smallestOrder;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date earliestentryDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date lastentryDate;
	private Integer accumulatedExecQty;
	private Integer numberOfValidOrders;
	private Integer numberOfInValidOrders;

	private Double executionPrice;

	public String getOrderBookID() {
		return orderBookID;
	}

	public void setOrderBookID(String orderBookID) {
		this.orderBookID = orderBookID;
	}

	public Integer getDemand() {
		return demand;
	}

	public void setDemand(Integer demand) {
		this.demand = demand;
	}

	public Integer getNumberofOrders() {
		return numberofOrders;
	}

	public void setNumberofOrders(Integer numberofOrders) {
		this.numberofOrders = numberofOrders;
	}

	public Integer getBiggestOrder() {
		return biggestOrder;
	}

	public void setBiggestOrder(Integer biggestOrder) {
		this.biggestOrder = biggestOrder;
	}

	public Integer getSmallestOrder() {
		return smallestOrder;
	}

	public void setSmallestOrder(Integer smallestOrder) {
		this.smallestOrder = smallestOrder;
	}

	public Date getEarliestentryDate() {
		return earliestentryDate;
	}

	public void setEarliestentryDate(Date earliestentryDate) {
		this.earliestentryDate = earliestentryDate;
	}

	public Date getLastentryDate() {
		return lastentryDate;
	}

	public void setLastentryDate(Date lastentryDate) {
		this.lastentryDate = lastentryDate;
	}

	public Integer getAccumulatedExecQty() {
		return accumulatedExecQty;
	}

	public void setAccumulatedExecQty(Integer accumulatedExecQty) {
		this.accumulatedExecQty = accumulatedExecQty;
	}

	public Integer getNumberOfValidOrders() {
		return numberOfValidOrders;
	}

	public void setNumberOfValidOrders(Integer numberOfValidOrders) {
		this.numberOfValidOrders = numberOfValidOrders;
	}

	public Integer getNumberOfInValidOrders() {
		return numberOfInValidOrders;
	}

	public void setNumberOfInValidOrders(Integer numberOfInValidOrders) {
		this.numberOfInValidOrders = numberOfInValidOrders;
	}

	public Double getExecutionPrice() {
		return executionPrice;
	}

	public void setExecutionPrice(Double executionPrice) {
		this.executionPrice = executionPrice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accumulatedExecQty == null) ? 0 : accumulatedExecQty.hashCode());
		result = prime * result + ((biggestOrder == null) ? 0 : biggestOrder.hashCode());
		result = prime * result + ((demand == null) ? 0 : demand.hashCode());
		result = prime * result + ((earliestentryDate == null) ? 0 : earliestentryDate.hashCode());
		result = prime * result + ((executionPrice == null) ? 0 : executionPrice.hashCode());
		result = prime * result + ((lastentryDate == null) ? 0 : lastentryDate.hashCode());
		result = prime * result + ((numberOfInValidOrders == null) ? 0 : numberOfInValidOrders.hashCode());
		result = prime * result + ((numberOfValidOrders == null) ? 0 : numberOfValidOrders.hashCode());
		result = prime * result + ((numberofOrders == null) ? 0 : numberofOrders.hashCode());
		result = prime * result + ((orderBookID == null) ? 0 : orderBookID.hashCode());
		result = prime * result + ((smallestOrder == null) ? 0 : smallestOrder.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderBookStatistics other = (OrderBookStatistics) obj;
		if (accumulatedExecQty == null) {
			if (other.accumulatedExecQty != null)
				return false;
		} else if (!accumulatedExecQty.equals(other.accumulatedExecQty))
			return false;
		if (biggestOrder == null) {
			if (other.biggestOrder != null)
				return false;
		} else if (!biggestOrder.equals(other.biggestOrder))
			return false;
		if (demand == null) {
			if (other.demand != null)
				return false;
		} else if (!demand.equals(other.demand))
			return false;
		if (earliestentryDate == null) {
			if (other.earliestentryDate != null)
				return false;
		} else if (!earliestentryDate.equals(other.earliestentryDate))
			return false;
		if (executionPrice == null) {
			if (other.executionPrice != null)
				return false;
		} else if (!executionPrice.equals(other.executionPrice))
			return false;
		if (lastentryDate == null) {
			if (other.lastentryDate != null)
				return false;
		} else if (!lastentryDate.equals(other.lastentryDate))
			return false;
		if (numberOfInValidOrders == null) {
			if (other.numberOfInValidOrders != null)
				return false;
		} else if (!numberOfInValidOrders.equals(other.numberOfInValidOrders))
			return false;
		if (numberOfValidOrders == null) {
			if (other.numberOfValidOrders != null)
				return false;
		} else if (!numberOfValidOrders.equals(other.numberOfValidOrders))
			return false;
		if (numberofOrders == null) {
			if (other.numberofOrders != null)
				return false;
		} else if (!numberofOrders.equals(other.numberofOrders))
			return false;
		if (orderBookID == null) {
			if (other.orderBookID != null)
				return false;
		} else if (!orderBookID.equals(other.orderBookID))
			return false;
		if (smallestOrder == null) {
			if (other.smallestOrder != null)
				return false;
		} else if (!smallestOrder.equals(other.smallestOrder))
			return false;
		return true;
	}

}
