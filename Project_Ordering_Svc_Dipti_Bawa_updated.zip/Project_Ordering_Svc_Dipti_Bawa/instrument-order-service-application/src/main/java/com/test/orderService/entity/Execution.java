package com.test.orderService.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document
public class Execution {

	@Id
	private String execID;
	private Integer execQuantity;
	private Double execPrice;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date execDate;
	private String bookID;

	public String getExecID() {
		return execID;
	}

	public void setExecID(String execID) {
		this.execID = execID;
	}

	public Integer getExecQuantity() {
		return execQuantity;
	}

	public void setExecQuantity(Integer execQuantity) {
		this.execQuantity = execQuantity;
	}

	public Double getExecPrice() {
		return execPrice;
	}

	public void setExecPrice(Double execPrice) {
		this.execPrice = execPrice;
	}

	public Date getExecDate() {
		return execDate;
	}

	public void setExecDate(Date execDate) {
		this.execDate = execDate;
	}

	public String getBookID() {
		return bookID;
	}

	public void setBookID(String bookID) {
		this.bookID = bookID;
	}

}
