package com.test.orderService.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.test.orderService.entity.Order;
import com.test.orderService.entity.OrderBook;

@Component("OrderBookDAOImpl")
@Repository
public class OrderBookDAOImpl implements OrderBookDAO {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public OrderBook closeOrderBook(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("bookID").is(id));

		OrderBook book = mongoTemplate.findOne(query, OrderBook.class);

		// modify and update with save()
		book.setIsOpen(false);
		book.setIsExecutionAllowed(true);
		mongoTemplate.save(book);
		return book;
	}

	@Override
	public void updateExecutionCompleted(Order order) {

		Query query = new Query();
		query.addCriteria(Criteria.where("bookID").is(order.getOrderBookID()));

		OrderBook book = mongoTemplate.findOne(query, OrderBook.class);

		book.setIsExecutionAllowed(false);
		mongoTemplate.save(book);
	}

}
