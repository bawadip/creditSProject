package com.test.orderService.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.test.orderService.entity.Order;

@Component("OrderDAOImpl")
@Repository
public class OrderDAOImpl implements OrderDAO {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Order addOrder(Order order) {
		mongoTemplate.save(order);
		return order;
	}

	@Override
	public void insertInvalidOrder(List<Order> orderlist) {
		orderlist.stream().forEach(order -> {
			order.setIsValid(false);
			mongoTemplate.save(order);
		});
	}

	@Override
	public void insertExecutedOrder(List<Order> orderlist) {
		orderlist.stream().forEach(order -> {
			mongoTemplate.save(order);
		});

	}

	@Override
	public List<Order> findOrderByIDs(List<String> idList) {
		Query query = new Query();
		query.addCriteria(Criteria.where("orderID").in(idList));

		return mongoTemplate.find(query, Order.class);

	}

}
