package com.test.orderService.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document
public class Order {

	// @Indexed(name="orderId", unique=true)
	@Id
	private String orderID;
	private String orderBookID;
	private String priceType;
	private Integer quantity;
	private Boolean isValid;
	private Double price;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date entryDate;
	private Double executedPrice;
	private Integer executedQuantity;
	private Boolean isExecutionCompleted;

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getPriceType() {
		return priceType;
	}

	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getOrderBookID() {
		return orderBookID;
	}

	public void setOrderBookID(String orderBookID) {
		this.orderBookID = orderBookID;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public Integer getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Integer executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getExecutedPrice() {
		return executedPrice;
	}

	public void setExecutedPrice(Double executedPrice) {
		this.executedPrice = executedPrice;
	}

	public Boolean getIsExecutionCompleted() {
		return isExecutionCompleted;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (entryDate == null) {
			if (other.entryDate != null)
				return false;
		} else if (!entryDate.equals(other.entryDate))
			return false;
		if (executedPrice == null) {
			if (other.executedPrice != null)
				return false;
		} else if (!executedPrice.equals(other.executedPrice))
			return false;
		if (executedQuantity == null) {
			if (other.executedQuantity != null)
				return false;
		} else if (!executedQuantity.equals(other.executedQuantity))
			return false;
		if (isExecutionCompleted == null) {
			if (other.isExecutionCompleted != null)
				return false;
		} else if (!isExecutionCompleted.equals(other.isExecutionCompleted))
			return false;
		if (isValid == null) {
			if (other.isValid != null)
				return false;
		} else if (!isValid.equals(other.isValid))
			return false;
		if (orderBookID == null) {
			if (other.orderBookID != null)
				return false;
		} else if (!orderBookID.equals(other.orderBookID))
			return false;
		if (orderID == null) {
			if (other.orderID != null)
				return false;
		} else if (!orderID.equals(other.orderID))
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (priceType == null) {
			if (other.priceType != null)
				return false;
		} else if (!priceType.equals(other.priceType))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		return true;
	}

	public void setIsExecutionCompleted(Boolean isExecutionCompleted) {
		this.isExecutionCompleted = isExecutionCompleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entryDate == null) ? 0 : entryDate.hashCode());
		result = prime * result + ((executedPrice == null) ? 0 : executedPrice.hashCode());
		result = prime * result + ((executedQuantity == null) ? 0 : executedQuantity.hashCode());
		result = prime * result + ((isExecutionCompleted == null) ? 0 : isExecutionCompleted.hashCode());
		result = prime * result + ((isValid == null) ? 0 : isValid.hashCode());
		result = prime * result + ((orderBookID == null) ? 0 : orderBookID.hashCode());
		result = prime * result + ((orderID == null) ? 0 : orderID.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((priceType == null) ? 0 : priceType.hashCode());
		result = prime * result + ((quantity == null) ? 0 : quantity.hashCode());
		return result;
	}

}
