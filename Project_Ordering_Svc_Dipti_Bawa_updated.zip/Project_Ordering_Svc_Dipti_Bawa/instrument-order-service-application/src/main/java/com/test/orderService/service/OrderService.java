package com.test.orderService.service;

import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.test.orderService.dao.OrderBookRepository;
import com.test.orderService.dao.OrderDAO;
import com.test.orderService.dao.OrderRepository;
import com.test.orderService.entity.Order;
import com.test.orderService.util.ApplicationConstants;

@Component
public class OrderService implements OrderServiceInt {

	@Autowired
	@Qualifier("OrderDAOImpl")
	OrderDAO orderDAO;

	@Autowired
	OrderBookRepository orderBookRepository;

	@Autowired
	OrderRepository orderRepository;

	public Order addOrder(Order order) {

		String uniqueID = UUID.randomUUID().toString();
		order.setOrderID(uniqueID);
		Date date = new Date();
		if (ApplicationConstants.MARKET_ORDER.equalsIgnoreCase(order.getPriceType())) {
			order.setPrice(null);
			order.setPriceType(ApplicationConstants.MARKET_ORDER);
		}

		if (ApplicationConstants.LIMIT_ORDER.equalsIgnoreCase(order.getPriceType())) {

			order.setPriceType(ApplicationConstants.LIMIT_ORDER);
		}
		order.setEntryDate(date);
		order.setIsValid(true);
		order.setExecutedQuantity(0);
		order.setIsExecutionCompleted(false);
		orderRepository.save(order);

		return order;
	}

	@Override
	public Order getOrder(String orderID) {
		// TODO Auto-generated method stub
		if (orderRepository.findOne(orderID) == null)
			return null;
		return orderRepository.findOne(orderID);
	}

}
