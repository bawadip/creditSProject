package com.test.orderService.dao;

import java.util.List;

import com.test.orderService.entity.Instrument;

public interface InstrumentDAO {
	List<Instrument> getAllInstruments();

	Instrument getInstrumentById(Integer id);

	Instrument addInstrument(Instrument instrument);

}
