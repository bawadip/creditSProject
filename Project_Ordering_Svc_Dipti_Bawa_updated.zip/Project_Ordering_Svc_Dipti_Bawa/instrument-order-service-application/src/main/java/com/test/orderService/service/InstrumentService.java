package com.test.orderService.service;

import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.test.orderService.dao.InstrumentRepository;
import com.test.orderService.entity.Instrument;

@Component
public class InstrumentService {

	private final Logger LOG = LoggerFactory.getLogger(InstrumentService.class);

	@Autowired
	InstrumentRepository instrumentRepository;

	public Instrument getInstrumentById(String Id) {
		return instrumentRepository.findOne(Id);
	}

	public Instrument addNewInstrument(@RequestBody Instrument instrument) {
		instrument.setName(instrument.getName().toUpperCase());

		String uniqueID = UUID.randomUUID().toString();
		instrument.setInstrumentID(uniqueID);
		instrumentRepository.save(instrument);
		return instrument;
	}

	public Instrument getInstrumentByName(String name) {
		return instrumentRepository.findByName(name);
	}

	public List<Instrument> getAllInstruments() {
		LOG.info("Getting all instruments.");
		List<Instrument> instrumentList = instrumentRepository.findAll();
		return instrumentList;
	}
}
