package com.test.orderService.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.test.orderService.dao.InstrumentRepository;
import com.test.orderService.dao.OrderBookDAO;
import com.test.orderService.dao.OrderBookRepository;
import com.test.orderService.dao.OrderDAO;
import com.test.orderService.dao.OrderRepository;
import com.test.orderService.entity.Execution;
import com.test.orderService.entity.Instrument;
import com.test.orderService.entity.LimitBreakDown;
import com.test.orderService.entity.Order;
import com.test.orderService.entity.OrderBook;
import com.test.orderService.entity.OrderBookStatistics;
import com.test.orderService.util.ApplicationConstants;

@Component
public class OrderBookService implements OrderBookServiceInt {

	@Autowired
	@Qualifier("OrderBookDAOImpl")
	OrderBookDAO orderBookDAO;

	@Autowired
	@Qualifier("OrderDAOImpl")
	OrderDAO orderDAO;

	@Autowired
	OrderBookRepository orderBookRepository;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	InstrumentRepository instrumentRepository;

	public OrderBook addOrderBook(Instrument inst) {
		OrderBook ob = new OrderBook();
		ob.setIsOpen(true);
		String uniqueID = UUID.randomUUID().toString();
		ob.setBookID(uniqueID);
		ob.setIsExecutionAllowed(false);
		ob.setInstrumentID(inst.getInstrumentID());

		orderBookRepository.save(ob);

		return ob;
	}

	@Override
	public OrderBook closeOrderBook(String bookId) {

		OrderBook closedOrderBook = new OrderBook();
		try {

			closedOrderBook = orderBookDAO.closeOrderBook(bookId);
		} catch (Exception e) {
			e.getStackTrace();
		}
		return closedOrderBook;
	}

	@Override
	public String executeBook(Execution exec) {
		{
			// check validity
			List<String> invalidIDList = new ArrayList<>();
			List<String> validIDList = new ArrayList<>();
			List<Order> orderList = orderRepository.findBybookID(exec.getBookID());
			orderList.forEach(order -> {
				if (ApplicationConstants.LIMIT_ORDER.equalsIgnoreCase(order.getPriceType())
						&& order.getPrice() < exec.getExecPrice())
					invalidIDList.add(order.getOrderID());
				else {
					if (!order.getIsExecutionCompleted())
						validIDList.add(order.getOrderID());
				}
			});

			if (!invalidIDList.isEmpty()) {
				List<Order> invalidorders = orderDAO.findOrderByIDs(validIDList);
				orderDAO.insertInvalidOrder(invalidorders);
			}
			if (!validIDList.isEmpty()) {
				List<Order> validOrders = orderDAO.findOrderByIDs(validIDList);
				List<Order> orders = executeOrder(validOrders, exec);
				orderDAO.insertExecutedOrder(orders);
			} else {
				return "Not a valid Execution request";
			}
		}

		return "book executed";
	}

	public List<Order> executeOrder(List<Order> orderlist, Execution exec) {
		double accumulatedQuantity = 0;

		synchronized (this) {
			for (Order order2 : orderlist) {
				accumulatedQuantity = accumulatedQuantity + (order2.getQuantity() - order2.getExecutedQuantity());
			}
			while (accumulatedQuantity != 0 && exec.getExecQuantity() > 0) {
				double allocatedExecQuantity = 0;
				for (Order order2 : orderlist) {
					if (!order2.getIsExecutionCompleted()) {
						Integer executeQuantity = (int) Math
								.round(((order2.getQuantity() - order2.getExecutedQuantity()) / accumulatedQuantity)
										* exec.getExecQuantity());
						if (executeQuantity > (order2.getQuantity() - order2.getExecutedQuantity())) {
							executeQuantity = order2.getQuantity() - order2.getExecutedQuantity();
						}
						if (executeQuantity > (exec.getExecQuantity() - allocatedExecQuantity)) {
							executeQuantity = (int) (exec.getExecQuantity() - allocatedExecQuantity);
						}
						allocatedExecQuantity = allocatedExecQuantity + executeQuantity;
						order2.setExecutedQuantity(order2.getExecutedQuantity() + executeQuantity);
					}
				}
				exec.setExecQuantity(exec.getExecQuantity() - (int) Math.round(allocatedExecQuantity));
				accumulatedQuantity = 0;
				for (Order order2 : orderlist) {
					accumulatedQuantity = accumulatedQuantity + (order2.getQuantity() - order2.getExecutedQuantity());
				}
			}

		}

		orderlist.stream().forEach(order -> {
			if (order.getExecutedQuantity().equals(order.getQuantity())) {
				order.setIsExecutionCompleted(true);
			}
			order.setExecutedPrice(exec.getExecPrice());
		});

		boolean isBookCompletelyExecuted = true;

		for (Order order2 : orderlist) {
			if (!order2.getIsExecutionCompleted()) {
				isBookCompletelyExecuted = false;

			}
			if (!isBookCompletelyExecuted)
				break;
		}

		if (isBookCompletelyExecuted)
			orderBookDAO.updateExecutionCompleted(orderlist.get(0));

		return orderlist;
	}

	@Override
	public boolean isValidInstrument(String id) {
		Instrument inst = instrumentRepository.findOne(id);

		if (inst == null) {
			return false;
		}
		return true;
	}

	@Override
	public List<OrderBook> findBookByInstID(String instrumentID) {
		List<OrderBook> oblist = orderBookRepository.findByInstID(instrumentID);
		return oblist;
	}

	@Override
	public OrderBook getBook(String id) {
		OrderBook ob = orderBookRepository.findOne(id);
		return ob;
	}

	@Override
	public OrderBookStatistics getOrderBookStatistics(String bookId) {
		List<Order> orderlist = getAllOrdersForBook(bookId);
		int demand = 0;
		int numberofValidOrders = 0;
		int numberofInValidOrders = 0;
		int accumulatedExecQty = 0;

		if (orderlist.size() == 0)
			return null;

		for (Order order : orderlist) {
			demand = demand + order.getQuantity();
			accumulatedExecQty = accumulatedExecQty + order.getExecutedQuantity();
			if (order.getIsValid()) {
				numberofValidOrders++;
			} else {
				numberofInValidOrders++;

			}
		}

		OrderBookStatistics stats = new OrderBookStatistics();
		stats.setNumberofOrders(orderlist.size());

		Collections.sort(orderlist, new Comparator<Order>() {
			@Override
			public int compare(Order o1, Order o2) {
				return o1.getEntryDate().compareTo(o2.getEntryDate());
			}
		});
		int size = orderlist.size();

		stats.setLastentryDate(orderlist.get(size - 1).getEntryDate());
		stats.setExecutionPrice(orderlist.get(size - 1).getExecutedPrice());
		// System.out.println(orderlist.get(size - 1).getEntryDate());

		stats.setEarliestentryDate(orderlist.get(0).getEntryDate());

		Collections.sort(orderlist, new Comparator<Order>() {
			@Override
			public int compare(Order o1, Order o2) {
				return o1.getQuantity() - o2.getQuantity();
			}
		});

		stats.setBiggestOrder(orderlist.get(size - 1).getQuantity());
		stats.setSmallestOrder(orderlist.get(0).getQuantity());
		stats.setOrderBookID(bookId);
		stats.setDemand(demand);
		stats.setNumberOfValidOrders(numberofValidOrders);
		stats.setNumberOfInValidOrders(numberofInValidOrders);
		stats.setAccumulatedExecQty(accumulatedExecQty);

		return stats;
	}

	@Override
	public List<Order> getAllOrdersForBook(String bookId) {
		// TODO Auto-generated method stub

		List<Order> orderList = orderRepository.findBybookID(bookId);
		if (orderList == null)
			return null;
		return orderList;
	}

	@Override
	public List<LimitBreakDown> getOrderBookLimitBreakdown(String bookId) {
		// TODO Auto-generated method stub
		List<Order> orderlist = getAllOrdersForBook(bookId);
		Map<Double, Integer> lbdMap = new HashMap<Double, Integer>();

		for (Order order : orderlist) {
			if (ApplicationConstants.LIMIT_ORDER.equalsIgnoreCase(order.getPriceType())) {
				if (lbdMap.containsKey(order.getPrice()))

				{
					int value = lbdMap.get(order.getPrice());
					lbdMap.put(order.getPrice(), value + order.getQuantity());

				} else {
					lbdMap.put(order.getPrice(), order.getQuantity());
				}

			}

		}
		List<LimitBreakDown> breakdwonList = new ArrayList<LimitBreakDown>();

		if (!CollectionUtils.isEmpty(lbdMap)) {

			for (Entry<Double, Integer> entry : lbdMap.entrySet()) {
				breakdwonList.add(new LimitBreakDown(entry.getKey(), entry.getValue()));
			}
		}

		return breakdwonList;
	}

	@Override
	public List<OrderBook> fetchOrderBooks() {
		List<OrderBook> orderBookList = orderBookRepository.findAll();
		return orderBookList;
	}

}
