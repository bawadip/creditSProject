package com.test.orderService.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.test.orderService.entity.Order;

@Repository
public interface OrderRepository extends MongoRepository<Order, String> {

	@Query("{ 'orderBookID': ?0}")
	List<Order> findBybookID(String orderBookID);

}
