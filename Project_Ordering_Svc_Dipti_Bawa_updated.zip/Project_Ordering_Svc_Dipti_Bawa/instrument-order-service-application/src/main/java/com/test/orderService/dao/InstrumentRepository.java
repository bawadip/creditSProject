package com.test.orderService.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.test.orderService.entity.Instrument;

public interface InstrumentRepository extends MongoRepository<Instrument, String> {

	@Query("{ 'name': ?0}")
	Instrument findByName(String name);
}
