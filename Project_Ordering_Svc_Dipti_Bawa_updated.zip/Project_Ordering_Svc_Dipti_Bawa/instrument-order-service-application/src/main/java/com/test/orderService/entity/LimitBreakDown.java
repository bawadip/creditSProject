package com.test.orderService.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class LimitBreakDown {

	@Id
	private Integer demand;
	private Double limitPrice;

	public Integer getDemand() {
		return demand;
	}

	public LimitBreakDown() {
		super();
	}

	public void setDemand(Integer demand) {
		this.demand = demand;
	}

	public Double getLimitPrice() {
		return limitPrice;
	}

	public void setLimitPrice(Double limitPrice) {
		this.limitPrice = limitPrice;
	}

	public LimitBreakDown(Double price, Integer demand) {
		this.demand = demand;
		this.limitPrice = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((limitPrice == null) ? 0 : limitPrice.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LimitBreakDown other = (LimitBreakDown) obj;
		if (limitPrice == null) {
			if (other.limitPrice != null)
				return false;
		} else if (!limitPrice.equals(other.limitPrice))
			return false;
		return true;
	}
}
