package com.test.orderService.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.orderService.entity.Execution;
import com.test.orderService.entity.Instrument;
import com.test.orderService.entity.LimitBreakDown;
import com.test.orderService.entity.Order;
import com.test.orderService.entity.OrderBook;
import com.test.orderService.entity.OrderBookStatistics;
import com.test.orderService.service.InstrumentService;
import com.test.orderService.service.OrderBookServiceInt;
import com.test.orderService.service.OrderServiceInt;
import com.test.orderService.util.ApplicationConstants;
import com.test.orderService.util.CustomErrorType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@Api(value = "Ordering Sservice", description = "Allows users to open order book,add orders,close and execute book")
public class OrderController {

	private final Logger LOG = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	InstrumentService instrumentService;

	@Autowired
	OrderBookServiceInt orderBookService;

	@Autowired
	OrderServiceInt orderService;

	// Adds a new OrderBook - in payload accepts Order Book object is json

	@ApiOperation(value = "Adds an Order Book, takes instrumentID in the request payload", response = OrderBook.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Book Added", response = OrderBook.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 409, message = "An open Book already exists for this Instrument") })

	@RequestMapping(value = "/addOrderBook", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> addOrderBook(@RequestBody Instrument instrument) {
		LOG.info("Adding a new Order Book ");
		if (orderBookService.isValidInstrument(instrument.getInstrumentID())) {
			List<OrderBook> orderbookList = orderBookService.findBookByInstID(instrument.getInstrumentID());

			if (CollectionUtils.isEmpty(orderbookList)) {

				boolean anyOpenBook = false;
				String anyOpenBookID = null;

				for (OrderBook orderBook : orderbookList) {
					if (orderBook.getIsOpen()) {
						anyOpenBook = true;
						anyOpenBookID = orderBook.getBookID();
						break;
					}
				}
				if (anyOpenBook) {

					LOG.error(
							"Unable to create. An OrderBook for instrtrument  {} with bookID  {} already exists in Open State",
							instrument.getInstrumentID(), anyOpenBookID);
					return new ResponseEntity<>(
							new CustomErrorType(
									"Unable to create. An OrderBook for instrtrument " + instrument.getInstrumentID()
											+ " already exists with bookID " + anyOpenBookID + " in Open State"),
							HttpStatus.CONFLICT);

				}

			}
		} else {
			LOG.error("Invalid instrtrument {}", instrument.getInstrumentID());
			return new ResponseEntity<>(new CustomErrorType("Invalid instrtrument " + instrument.getInstrumentID()),
					HttpStatus.BAD_REQUEST);
		}
		OrderBook createdOrderBook = orderBookService.addOrderBook(instrument);

		return new ResponseEntity<OrderBook>(createdOrderBook, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Fetches Book Details for a given bookID", response = OrderBook.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = OrderBook.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "Book Not Found with the given bookID") })
	@RequestMapping(value = "/orderBook/{bookID}", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> getBook(@PathVariable String bookID) {
		LOG.info("Getting book details");
		OrderBook ob = orderBookService.getBook(bookID);
		if (ob == null)
			return new ResponseEntity<>(new CustomErrorType("Book Not Found with the given bookID"),
					HttpStatus.NOT_FOUND);

		return new ResponseEntity<OrderBook>(ob, HttpStatus.OK);
	}

	@ApiOperation(value = "Adds order to a given bookID", response = OrderBook.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = OrderBook.class),
			@ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "") })

	@RequestMapping(value = "/addOrder", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> addOrder(@RequestBody Order order) {

		if (orderBookService.getBook(order.getOrderBookID()) == null
				|| !orderBookService.getBook(order.getOrderBookID()).getIsOpen()) {
			return new ResponseEntity<>(
					new CustomErrorType("Unable to add an Order as OrderBook is closed or does not exist"),
					HttpStatus.CONFLICT);
		}

		if (!(ApplicationConstants.LIMIT_ORDER.equalsIgnoreCase(order.getPriceType())
				|| ApplicationConstants.MARKET_ORDER.equalsIgnoreCase(order.getPriceType()))) {
			return new ResponseEntity<>(
					new CustomErrorType("Unable to add an Order as Price type is invalid.Valid price types are M or L"),
					HttpStatus.BAD_REQUEST);
		}
		Order addedOrder = orderService.addOrder(order);
		return new ResponseEntity<Order>(addedOrder, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Closes book for a given bookID", response = OrderBook.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = OrderBook.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "Unable to close book. BookID not found") })

	@RequestMapping(value = "/closeOrderBook/{bookID}", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> closeBook(@PathVariable String bookID) {
		LOG.info("Getting all users.");
		OrderBook book = orderBookService.getBook(bookID);
		if (book == null) {
			LOG.error("Book {} not found", bookID);
			return new ResponseEntity<>(new CustomErrorType("Unable to close book. BookID " + bookID + " not found."),
					HttpStatus.NOT_FOUND);
		}
		OrderBook closedOrderBook = orderBookService.closeOrderBook(bookID);
		return new ResponseEntity<OrderBook>(closedOrderBook, HttpStatus.OK);
	}

	@ApiOperation(value = "Executes transactions on a given bookID")
	@ApiResponses(value = { @ApiResponse(code = 202, message = ""),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Not a valid Request. Either the book is open or no further executions are allowed on the book") })

	@RequestMapping(value = "/executeOrderBook", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> executeBook(@RequestBody Execution exec) {
		LOG.info("Executing Order Book.");

		if (exec.getBookID() != null && orderBookService.getBook(exec.getBookID()) != null
				&& !(orderBookService.getBook(exec.getBookID()).getIsOpen())
				&& orderBookService.getBook(exec.getBookID()).getIsExecutionAllowed()) {
			orderBookService.executeBook(exec);
		} else {
			return new ResponseEntity<>(new CustomErrorType(
					"Not a valid Request. Either the book is open or no further executions are allowed on the book "),
					HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

	@ApiOperation(value = "Get List of all Order Books", response = OrderBook.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = OrderBook.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "No Order Books Found") })

	@RequestMapping(value = "/allOrderBooks", method = RequestMethod.GET)
	public ResponseEntity<?> getAllOrderBooks() {
		LOG.info("Getting all instruments.");
		List<OrderBook> orderBookList = orderBookService.fetchOrderBooks();
		if (CollectionUtils.isEmpty(orderBookList))
			return new ResponseEntity<>(new CustomErrorType("No Order Books Found"), HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<OrderBook>>(orderBookList, HttpStatus.OK);
	}

	@ApiOperation(value = "Get Instrument Details by instrumentID  ", response = Instrument.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = Instrument.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "No Instrument found for given instrumentID") })
	@RequestMapping(value = "instrument/{Id}", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> getInstrumentById(@PathVariable String Id) {
		LOG.info("Getting Instrument by ID: {}.", Id);
		if (instrumentService.getInstrumentById(Id) == null)
			return new ResponseEntity<>(new CustomErrorType("No Instrument found for given instrumentID"),
					HttpStatus.BAD_REQUEST);
		return new ResponseEntity<Instrument>(instrumentService.getInstrumentById(Id), HttpStatus.OK);
	}

	@ApiOperation(value = "Add new Instrument ", response = Instrument.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = Instrument.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 409, message = "Unable to add instrument. Intrument already exists") })
	@RequestMapping(value = "/addInstrument", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> addNewInstrument(@RequestBody Instrument instrument) {
		instrument.setName(instrument.getName().toUpperCase());
		Instrument inst = instrumentService.getInstrumentByName(instrument.getName());
		if (inst != null) {
			LOG.error("instrument with name {} already exists", instrument.getName());
			return new ResponseEntity<>(
					new CustomErrorType(
							"Unable to add instrument. Intrument " + instrument.getName() + " already Exist."),
					HttpStatus.CONFLICT);
		}

		Instrument addedInstrument = instrumentService.addNewInstrument(instrument);
		return new ResponseEntity<Instrument>(addedInstrument, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Get List of all Instruments ", response = Instrument.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = Instrument.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "No Instruments Found") })

	@RequestMapping(value = "/allInstruments", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> getAllInstruments() {
		LOG.info("Getting all instruments.");
		List<Instrument> instrumentList = instrumentService.getAllInstruments();
		if (CollectionUtils.isEmpty(instrumentList)) {
			return new ResponseEntity<>(new CustomErrorType("No Instruments Found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Instrument>>(instrumentList, HttpStatus.OK);
	}

	// Get Order Details for a given Order ID

	@ApiOperation(value = "Get Order Details for a given orderID ", response = Order.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = Order.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "Unable to find order. OrderID not found") })

	@RequestMapping(value = "order/{orderID}", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> getOrderById(@PathVariable String orderID) {
		LOG.info("Getting Order Details by orderID: {}.", orderID);
		Order order = orderService.getOrder(orderID);
		if (order == null) {
			LOG.error("order {} not found", order);
			return new ResponseEntity<>(new CustomErrorType("Unable to find order. OrderID " + orderID + " not found."),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Order>(order, HttpStatus.OK);
	}

	@ApiOperation(value = "Get Order Book Statistics ", response = OrderBook.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = OrderBook.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "Unable to find  book. BookID not found") })

	@RequestMapping(value = "/getStatistics/{bookID}", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = "application/json")
	public ResponseEntity<?> getOrderBookStatistics(@PathVariable String bookID) {
		LOG.info("Getting Statistics for Order Book ID  {}.", bookID);
		OrderBook book = orderBookService.getBook(bookID);
		if (book == null) {
			LOG.error("Book {} not found", bookID);
			return new ResponseEntity<>(new CustomErrorType("Unable to find  book. BookID " + bookID + " not found."),
					HttpStatus.NOT_FOUND);
		}
		OrderBookStatistics stats = orderBookService.getOrderBookStatistics(bookID);
		if (stats == null)
			return new ResponseEntity<>(
					new CustomErrorType("No Orders in the book yet. Hence, no statistics available"),
					HttpStatus.NOT_FOUND);
		return new ResponseEntity<OrderBookStatistics>(stats, HttpStatus.OK);
	}

	@ApiOperation(value = "Get Limit Break Down for an Order Book ", response = LimitBreakDown.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = LimitBreakDown.class),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 404, message = "Unable to find  book. BookID not found") })

	@RequestMapping(value = "/getlimitbreakdown/{bookID}", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> getOrderBookLimitBreakdown(@PathVariable String bookID) {
		LOG.info("Getting Limit Breakdown for Order Book ID  {}.", bookID);
		OrderBook book = orderBookService.getBook(bookID);
		if (book == null) {
			LOG.error("Book {} not found", bookID);
			return new ResponseEntity<>(new CustomErrorType("Unable to find  book. BookID " + bookID + " not found."),
					HttpStatus.NOT_FOUND);
		}
		List<LimitBreakDown> lbd = orderBookService.getOrderBookLimitBreakdown(bookID);
		if (CollectionUtils.isEmpty(lbd)) {
			return new ResponseEntity<>(new CustomErrorType("No Orders with Price Type Limit exist on this Book"),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<LimitBreakDown>>(lbd, HttpStatus.OK);
	}
}