Functional Considerations:
-------------------------------------------------------------------------------------------------

APIs are written keeping in mind 3 kinds of users(with the following functional assumptions) :

1. Admin User : User who is responsible for adding instruments to the system.Folling functionalities are avialble to this user:
             a.Add a new Instrument
             b.Get all available Instrument
             c.Get instrument by instrumentID

2.Investor/Customer : User who is going to buy/sell instruments using this service. Following functionalities are avialble to this user:
             a) Add Order to Order Book.
	     b)Open an Order Book for a financial instrument.
             c)Close Order Book for a financial instrument
             
3.Broker/Investment Firm : User is who is going to execute the Order Book. Following functionalities are available to this user:
   
             a)Execute Orders
             b)Get Statistics Report for an Order Book
             c)Get Limit Break Down Report for an Order Book.

Technical Considerations:
---------------------------------------------------------------------------------------------------

1.Mongo DB has been used to persist data.
2.Spring Boot and Tomcat (embedded) has been used. 
3.Swagger documentation is added for the REST APIs.
4.Multi Layered application development approach is used to make the application easily extendable.
5.JSON is used for request/response payloads for easy adaptibility of the APIs by an external client(UI/other Services for service-to-service calls)

Swagger UI can be accessed at : http://localhost:8102/ordering-svc/swagger-ui.html


Pre-Requisites 
--------------------------------------------------------------------------------------------------------
Mongo DB should be running on localhost: 27017
Tomcat will use port 8102 as per the application.properties file.Hence, port should not be in use by any other process.

What else can we do
---------------------------------------------------------------------------------------------------------
1.Add JUNIT for unit testing of business logic
2.Code Refactoring.
3.For Exposing performance metrics of the application including: number of orders processed, processing time (min, max,
average - we can persisit the Execution entity and calculate relevant data points.



	     

